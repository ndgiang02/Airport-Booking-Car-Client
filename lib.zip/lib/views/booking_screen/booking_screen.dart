import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:get/get.dart';
import 'package:location/location.dart';
import 'package:vietmap_flutter_gl/vietmap_flutter_gl.dart';

import '../../constant/constant.dart';
import '../../constant/show_dialog.dart';
import '../../controllers/booking_controller.dart';
import '../../models/vehicle_model.dart';
import '../../utils/themes/button.dart';
import '../../utils/themes/contant_colors.dart';

class AirportScreen extends StatefulWidget {
  @override
  _AirportScreenState createState() => _AirportScreenState();
}

class _AirportScreenState extends State<AirportScreen> {
  
  
  final bookController = Get.find<BookingController>();

  String apiKey = Constant.VietMapApiKey;

  final CameraPosition _kInitialPosition =
      const CameraPosition(target: LatLng(10.762317, 106.654551), zoom: 15);

  final TextEditingController pickupController = TextEditingController();
  final TextEditingController destinationController = TextEditingController();
  final TextEditingController passengerController = TextEditingController();

  VietmapController? _mapController;

  final Location currentLocation = Location();

  @override
  void initState() {
    super.initState();
     pickupController.addListener(() {
      setState(() {});
    });
    destinationController.addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    pickupController.dispose();
    destinationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Booking'.tr,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue,
      ),
      body: Stack(
        children: [
          VietmapGL(
            dragEnabled: true,
            compassEnabled: false,
            trackCameraPosition: true,
            myLocationRenderMode: MyLocationRenderMode.COMPASS,
            myLocationTrackingMode: MyLocationTrackingMode.TrackingGPS,
            minMaxZoomPreference: MinMaxZoomPreference(0, 24),
            rotateGesturesEnabled: false,
            styleString:
                '${Constant.baseUrl}/maps/light/styles.json?apikey=$apiKey',
            initialCameraPosition: _kInitialPosition,
            onMapCreated: (VietmapController controller) async {
              _mapController = controller;
            },
          ),
          Positioned(
            top: 10,
            left: 10,
            right: 10,
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    children: [
                      buildTextField(
                        controller: pickupController,
                        hintText: 'From',
                        onClear: () {
                          pickupController.clear();
                          bookController.clearData();
                          _mapController?.clearLines();
                          _mapController?.clearSymbols();
                        },
                        onGetCurrentLocation: () => _getCurrentLocation(true),
                      ),
                      Divider(),
                      /*...stopoverControllers.map((controller) {
                              return Column(
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: buildTextField(
                                          controller: controller,
                                          prefixIcon: Icon(Icons.pin_drop, color: Colors.yellow),
                                          hintText: 'Stopover',
                                          onClear: () {
                                            stopoverControllers.clear();
                                          },
                                          onDeleteStop: () {
                                            stopoverControllers.remove(controller);
                                            controller.dispose();
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  Divider(), // Divider sau mỗi Stopover
                                ],
                              );
                            }).toList(),*/
                      buildTextField(
                        controller: destinationController,
                        hintText: 'To',
                        onClear: () {
                          destinationController.clear();
                          bookController.clearData();
                          _mapController?.clearLines();
                          _mapController?.clearSymbols();
                        },
                      ),
                      TextButton(
                        onPressed: () {
                          // stopoverControllers.add(TextEditingController());
                        },
                        style: TextButton.styleFrom(
                          padding:
                              EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.add_circle,
                              color: Colors.blue,
                              size: 16,
                            ),
                            SizedBox(width: 4),
                            Text(
                              "Add Stopover",
                              style: TextStyle(
                                color: Colors.blue,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Obx(() {
            return bookController.isMapDrawn.value
                ? Positioned(
                    bottom: 10,
                    left: 10,
                    right: 10,
                    child: confirmWidget(),
                  )
                : SizedBox.shrink();
          }),
        ],
      ),
    );
  }

  Widget buildTextField({
    required TextEditingController controller,
    required String hintText,
    void Function()? onClear,
    void Function()? onGetCurrentLocation,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.grey.shade100,
      ),
      child: TypeAheadField<Map<String, String>>(
        hideOnEmpty: true,
        hideOnLoading: true,
        textFieldConfiguration: TextFieldConfiguration(
          controller: controller,
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.location_on, color: Colors.grey),
            suffixIcon: controller.text.isNotEmpty
                ? IconButton(
                    icon: Icon(Icons.clear, color: Colors.grey),
                    onPressed: onClear,
                  )
                : onGetCurrentLocation != null
                    ? IconButton(
                        icon: Icon(Icons.my_location, color: Colors.grey),
                        onPressed: onGetCurrentLocation,
                      )
                    : null,
            hintText: hintText,
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
        suggestionsCallback: (pattern) async {
          return await bookController.getAutocompleteData(pattern);
        },
        itemBuilder: (context, suggestion) {
          return ListTile(
            leading: Icon(Icons.pin_drop_outlined, color: Colors.blue),
            title: Text(suggestion['display']!),
          );
        },
        onSuggestionSelected: (suggestion) async {
          controller.text = suggestion['display']!;
          LatLng? latLong =
              await bookController.reverseGeocode(suggestion['ref_id']!);
          controller.selection =
              TextSelection.fromPosition(TextPosition(offset: 0));
          FocusScope.of(context).unfocus();
          bookController.suggestions.clear();
          if (controller == pickupController) {
            bookController.setPickUpMarker(latLong!, _mapController);
          } else {
            bookController.setDestinationMaker(latLong!, _mapController);
          }
        },
      ),
    );
  }

  Future<void> _getCurrentLocation(bool pickup) async {
    final current = await bookController.getCurrentLocation();
    if (current != null) {
      if (pickup) {
        pickupController.text = current['display'];
      } else {
        destinationController.text = current['display'];
      }
    }
  }

  confirmWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: ButtonThem.buildIconButton(context,
                iconSize: 16.0,
                icon: Icons.arrow_back_ios,
                iconColor: Colors.black,
                btnHeight: 40,
                btnWidthRatio: 0.25,
                title: "Back".tr,
                btnColor: ConstantColors.cyan,
                txtColor: Colors.black, onPress: () {
                  bookController.isMapDrawn.value = false;
                }),
          ),
          Expanded(
            child: ButtonThem.buildButton(context,
                btnHeight: 40,
                title: "Continue".tr,
                btnColor: ConstantColors.primary,
                txtColor: Colors.white, onPress: () async {
              /* await controller.getDurationDistance(departureLatLong!, destinationLatLong!).then((durationValue) async {
                if (durationValue != null) {
                  await controller.getUserPendingPayment().then((value) async {
                    if (value != null) {
                      if (value['success'] == "success") {
                        if (value['data']['amount'] != 0) {
                          _pendingPaymentDialog(context);
                        } else {
                          if (Constant.distanceUnit == "KM") {
                            controller.distance.value = durationValue['rows'].first['elements'].first['distance']['value'] / 1000.00;
                          } else {
                            controller.distance.value = durationValue['rows'].first['elements'].first['distance']['value'] / 1609.34;
                          }

                          controller.duration.value = durationValue['rows'].first['elements'].first['duration']['text'];
                          // Get.back();
                          controller.confirmWidgetVisible.value = false;
                          tripOptionBottomSheet(context);
                        }
                      } else {
                        if (Constant.distanceUnit == "KM") {
                          controller.distance.value = durationValue['rows'].first['elements'].first['distance']['value'] / 1000.00;
                        } else {
                          controller.distance.value = durationValue['rows'].first['elements'].first['distance']['value'] / 1609.34;
                        }
                        controller.duration.value = durationValue['rows'].first['elements'].first['duration']['text'];
                        controller.confirmWidgetVisible.value = false;
                        // Get.back();
                        tripOptionBottomSheet(context);
                      }
                    }
                  });
                }
              });*/
            }),
          ),
        ],
      ),
    );
  }

  tripOptionBottomSheet(BuildContext context) {
    return showModalBottomSheet(
        context: context,
        isDismissible: false,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) {
          return Container(
            decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.all(Radius.circular(15))),
            margin: const EdgeInsets.all(10),
            child: StatefulBuilder(builder: (context, setState) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 20),
                child: Padding(
                  padding: MediaQuery.of(context).viewInsets,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Text(
                          "Trip option".tr,
                          style: const TextStyle(fontSize: 18, color: Colors.black),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextField(
                          controller: passengerController,
                          textInputAction: TextInputAction.done,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            focusedBorder: const OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey, width: 1.0),
                            ),
                            enabledBorder: const OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey, width: 1.0),
                            ),
                            labelText: 'How many passenger'.tr,
                            hintText: 'How many passenger'.tr,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 10),
                              child: ButtonThem.buildIconButton(context,
                                  iconSize: 16.0,
                                  icon: Icons.arrow_back_ios,
                                  iconColor: Colors.black,
                                  btnHeight: 40,
                                  btnWidthRatio: 0.25,
                                  title: "Back".tr,
                                  btnColor: ConstantColors.cyan,
                                  txtColor: Colors.black, onPress: () {
                                    Get.back();
                                  }),
                            ),
                            Expanded(
                              child:
                              ButtonThem.buildButton(context, btnHeight: 40, title: "Book Now".tr, btnColor: ConstantColors.primary, txtColor: Colors.white, onPress: () async {
                                if (passengerController.text.isEmpty) {
                                  ShowDialog.showToast("Please Enter Passenger".tr);
                                } else {
                                  await bookController.getVehicleCategory().then((value) {
                                    if (value != null) {
                                      if (value.success == "Success") {
                                        Get.back();
                                        // List tripPrice = [];
                                        // for (int i = 0;
                                        //     i < value.vehicleData!.length;
                                        //     i++) {
                                        //   tripPrice.add(0.0);
                                        // }
                                        // if (value.vehicleData!.isNotEmpty) {
                                        //   for (int i = 0;
                                        //       i < value.vehicleData!.length;
                                        //       i++) {
                                        //     if (controller.distance.value >
                                        //         value.vehicleData![i]
                                        //             .minimumDeliveryChargesWithin!
                                        //             .toDouble()) {
                                        //       tripPrice.add((controller
                                        //                   .distance.value *
                                        //               value.vehicleData![i]
                                        //                   .deliveryCharges!)
                                        //           .toDouble()
                                        //           .toStringAsFixed(
                                        //               int.parse(Constant.decimal ?? "2")));
                                        //     } else {
                                        //       tripPrice.add(value
                                        //           .vehicleData![i]
                                        //           .minimumDeliveryCharges!
                                        //           .toDouble()
                                        //           .toStringAsFixed(
                                        //               int.parse(Constant.decimal ?? "2")));
                                        //     }
                                        //   }
                                        // }
                                        chooseVehicleBottomSheet(
                                          context,
                                          value,
                                        );
                                      }
                                    }
                                  });
                                }
                              }),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );
            }),
          );
        });
  }

  chooseVehicleBottomSheet(BuildContext context, VehicleCategoryModel vehicleCategoryModel) {
    return showModalBottomSheet(
        context: context,
        isDismissible: false,
        enableDrag: true,
        backgroundColor: Colors.transparent,
        builder: (context) {
          return Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(
                Radius.circular(15),
              ),
            ),
            margin: const EdgeInsets.all(10),
            child: StatefulBuilder(builder: (context, setState) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Text(
                        "Choose Your Vehicle Type".tr,
                        style: const TextStyle(fontSize: 18, color: Colors.black),
                      ),
                    ),
                    Divider(
                      color: Colors.grey.shade700,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              Image.asset("assets/icons/ic_distance.png", height: 24, width: 24),
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Text("Distance".tr, style: const TextStyle(fontSize: 16)),
                              )
                            ],
                          ),
                        ),
                        Text("${bookController.distance.value.toStringAsFixed(2)} ${Constant.distanceUnit}")
                      ],
                    ),
                    Divider(
                      color: Colors.grey.shade700,
                    ),
                    Expanded(
                      child: ListView.builder(
                          itemCount: vehicleCategoryModel.data!.length,
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return Obx(
                                  () => InkWell(
                                onTap: () {
                                  bookController.vehicleData = vehicleCategoryModel.data![index];
                                  bookController.selectedVehicle.value = vehicleCategoryModel.data![index].id.toString();
                                },
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color: bookController.selectedVehicle.value == vehicleCategoryModel.data![index].id.toString()
                                            ? ConstantColors.primary
                                            : Colors.black.withOpacity(0.10),
                                        borderRadius: BorderRadius.circular(8)),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                      child: Row(
                                        children: [
                                          CachedNetworkImage(
                                            imageUrl: vehicleCategoryModel.data![index].image.toString(),
                                            fit: BoxFit.fill,
                                            width: 80,
                                            height: 50,
                                            placeholder: (context, url) => Constant.loader(),
                                            errorWidget: (context, url, error) =>Image.asset(
                                              "assets/images/appIcon.png",
                                            ),
                                          ),
                                          Expanded(
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(left: 10),
                                                    child: Text(
                                                      vehicleCategoryModel.data![index].libelle.toString(),
                                                      textAlign: TextAlign.start,
                                                      style: TextStyle(
                                                          fontSize: 18,
                                                          color: bookController.selectedVehicle.value == vehicleCategoryModel.data![index].id.toString() ? Colors.white : Colors.black,
                                                          fontWeight: FontWeight.w500),
                                                    ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets.only(top: 5),
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    children: [
                                                      Text(
                                                        bookController.duration.value,
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: bookController.selectedVehicle.value == vehicleCategoryModel.data![index].id.toString() ? Colors.white : Colors.black,
                                                        ),
                                                      ),
                                                      Text(
                                                        Constant().amountShow(
                                                            amount: "${bookController.calculateTripPrice(
                                                              distance: bookController.distance.value,
                                                              deliveryCharges: double.parse(vehicleCategoryModel.data![index].deliveryCharges!),
                                                              minimumDeliveryCharges: double.parse(vehicleCategoryModel.data![index].minimumDeliveryCharges!),
                                                              minimumDeliveryChargesWithin: double.parse(vehicleCategoryModel.data![index].minimumDeliveryChargesWithin!),
                                                            )}"),
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: bookController.selectedVehicle.value == vehicleCategoryModel.data![index].id.toString() ? Colors.white : Colors.black,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: ButtonThem.buildIconButton(context,
                                iconSize: 16.0,
                                icon: Icons.arrow_back_ios,
                                iconColor: Colors.black,
                                btnHeight: 40,
                                btnWidthRatio: 0.25,
                                title: "Back".tr,
                                btnColor: ConstantColors.cyan,
                                txtColor: Colors.black, onPress: () {
                                  Get.back();
                                  tripOptionBottomSheet(context);
                                }),
                          ),
                          Expanded(
                            child:
                            ButtonThem.buildButton(context, btnHeight: 40, title: "Book Now".tr, btnColor: ConstantColors.primary, txtColor: Colors.white, onPress: () async {
                              /*if (bookController.selectedVehicle.value.isNotEmpty) {
                                double cout = 0.0;

                                if (bookController.distance.value > double.parse(bookController.vehicleData!.minimumDeliveryChargesWithin!)) {
                                  cout = (bookController.distance.value * double.parse(bookController.vehicleData!.deliveryCharges!)).toDouble();
                                } else {
                                  cout = double.parse(bookController.vehicleData!.minimumDeliveryCharges.toString());
                                }
                                
                                await bookController
                                    .getDriverDetails(bookController.vehicleData!.id.toString(), departureLatLong!.latitude.toString(), departureLatLong!.longitude.toString())
                                    .then((value) {
                                  if (value != null) {
                                    if (value.success == "Success") {
                                      // List<DriverData> driverData = [];
                                      // for (var i = 0; i < value.data!.length; i++) {
                                      //   if (double.parse(Constant.driverRadius!) >= double.parse(value.data![i].distance!)) {
                                      //     driverData.add(value.data![i]);
                                      //   }
                                      // }
                                      if (value.data!.isNotEmpty) {
                                        Get.back();
                                        conformDataBottomSheet(context, value.data![0], cout);
                                      } else {
                                        ShowDialog.showToast("Driver not found in your area.".tr);
                                      }
                                    } else {
                                      ShowDialog.showToast("Driver not found in your area.".tr);
                                    }
                                  }
                                });
                              } else {
                                ShowDialog.showToast("Please select Vehicle Type".tr);
                              }*/
                            }),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }),
          );
        });
  }



}
