import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:get/get.dart';
import 'package:location/location.dart';
import 'package:vietmap_flutter_gl/vietmap_flutter_gl.dart';

import '../../constant/constant.dart';
import '../../controllers/booking_controller.dart';
import '../../controllers/testcontroller.dart';
import '../../utils/themes/button.dart';
import '../../utils/themes/contant_colors.dart';

class Test extends StatefulWidget {
  @override
  _AirportScreenState createState() => _AirportScreenState();
}

class _AirportScreenState extends State<Test> {

  final bookController = Get.put(TestController());

  String apiKey = Constant.VietMapApiKey;

  List<LatLng> points = [];

  Map<String, MarkerLayer> markers = {};

  final CameraPosition _kInitialPosition =
  const CameraPosition(target: LatLng(10.762317, 106.654551), zoom: 15);

  final TextEditingController pickupController = TextEditingController();
  final TextEditingController destinationController = TextEditingController();

  final controller = Get.put(TestController());
  final Location currentLocation = Location();

  LatLng? pickupLatLong;
  LatLng? destinationLatLong;

  PolylinePoints polylinePoints = PolylinePoints();

  VietmapController? _mapController;

  @override
  void initState() {
    super.initState();
     pickupController.addListener(() {
      setState(() {});
    });
    destinationController.addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    pickupController.dispose();
    destinationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Booking'.tr,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue,
      ),
      body: Stack(
        children: [
          VietmapGL(
            dragEnabled: true,
            compassEnabled: false,
            trackCameraPosition: true,
            myLocationRenderMode: MyLocationRenderMode.COMPASS,
            myLocationTrackingMode: MyLocationTrackingMode.TrackingGPS,
            myLocationEnabled: true,
            minMaxZoomPreference: MinMaxZoomPreference(0, 24),
            rotateGesturesEnabled: false,
            styleString:
            '${Constant.baseUrl}/maps/light/styles.json?apikey=$apiKey',
            initialCameraPosition: _kInitialPosition,
            onMapCreated: (VietmapController controller) async {
              _mapController = controller;
            },
          ),
          Positioned(
            top: 10,
            left: 10,
            right: 10,
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    children: [
                      InkWell(
                        onTap: () {
                          setPickUpMarker(pickupLatLong!);
                        },
                        child: buildTextField(
                          controller: pickupController,
                          hintText: 'From',
                          onClear: () {
                            pickupController.clear();
                            pickupLatLong = null;
                            _mapController?.clearLines();
                            _mapController?.clearSymbols();
                          },
                          onGetCurrentLocation: () => _getCurrentLocation(true),
                        ),
                      ),
                      Divider(),
                      /*...stopoverControllers.map((controller) {
                              return Column(
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: buildTextField(
                                          controller: controller,
                                          prefixIcon: Icon(Icons.pin_drop, color: Colors.yellow),
                                          hintText: 'Stopover',
                                          onClear: () {
                                            stopoverControllers.clear();
                                          },
                                          onDeleteStop: () {
                                            stopoverControllers.remove(controller);
                                            controller.dispose();
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  Divider(), // Divider sau mỗi Stopover
                                ],
                              );
                            }).toList(),*/
                      InkWell(
                        onTap: () {
                          setDestinationMaker(destinationLatLong!);
                        },
                        child: buildTextField(
                          controller: destinationController,
                          hintText: 'To',
                          onClear: () {
                            destinationController.clear();
                            destinationLatLong = null;
                            _mapController?.clearLines();
                            _mapController?.clearSymbols();
                          },
                        ),
                      ),
                      TextButton(
                        onPressed: () {

                          // stopoverControllers.add(TextEditingController());
                        },
                        style: TextButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.add_circle,
                              color: Colors.blue,
                              size: 16,
                            ),
                            SizedBox(width: 4),
                            Text(
                              "Add Stopover",
                              style: TextStyle(
                                color: Colors.blue,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Visibility(
            visible: controller.confirmWidgetVisible.value,
            child: Align(
              alignment: Alignment.bottomCenter,
              child: confirmWidget(),
            ),
          ),
        ],
      ),
    );
  }



  Widget buildTextField({
    required TextEditingController controller,
    required String hintText,
    void Function()? onClear,
    void Function()? onGetCurrentLocation,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.grey.shade100,
      ),
      child: TypeAheadField<Map<String, String>>(
        hideOnEmpty: true,
        hideOnLoading: true,
        textFieldConfiguration: TextFieldConfiguration(
          controller: controller,
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.location_on, color: Colors.grey),
            suffixIcon: controller.text.isNotEmpty
                ? IconButton(
              icon: Icon(Icons.clear, color: Colors.grey),
              onPressed: onClear,
            )
                : onGetCurrentLocation != null
                ? IconButton(
              icon: Icon(Icons.my_location, color: Colors.grey),
              onPressed: onGetCurrentLocation,
            )
                : null,
            hintText: hintText,
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
        suggestionsCallback: (pattern) async {
          return await bookController.getAutocompleteData(pattern);
        },
        itemBuilder: (context, suggestion) {
          return ListTile(
            leading: Icon(Icons.pin_drop_outlined, color: Colors.blue),
            title: Text(suggestion['display']!),
          );
        },
        onSuggestionSelected: (suggestion) async {
          controller.text = suggestion['display']!;
          LatLng? latLong = await bookController.reverseGeocode(suggestion['ref_id']!);
          controller.selection = TextSelection.fromPosition(TextPosition(offset: 0));
          FocusScope.of(context).unfocus();
          bookController.suggestions.clear();

          /*if (controller == pickupController) {
            bookController.setPickUpMarker(latLong!, _mapController);
          } else {
            bookController.setDestinationMaker(latLong!, _mapController);
          }*/
        },
      ),
    );
  }

  Future<void> _getCurrentLocation(bool pickup) async {
    final current = await bookController.getCurrentLocation(pickupLatLong!);
    if (current != null) {
      if (pickup) {
        pickupController.text = current['display'];
      } else {
        destinationController.text = current['display'];
      }
    }
  }

  Future<void> setPickUpMarker(LatLng pickup) async {
    markers.remove('Pickup');

    pickupLatLong = pickup;
    points.insert(0, pickupLatLong!);

    markers['Pickup'] = MarkerLayer(
      ignorePointer: true,
      mapController: _mapController!,
      markers: [
        Marker(
          alignment: Alignment.bottomCenter,
          width: 30,
          height: 30,
          child: Icon(
            Icons.location_on,
            color: Colors.red,
            size: 30,
          ),
          latLng: LatLng(pickup.latitude, pickup.longitude),
        ),
      ],
    );
    _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(pickup.latitude, pickup.longitude),
        zoom: 14,
      )),
    );

    await bookController.fetchRouteData();
    bookController.addPolyline(_mapController);

    if (pickupLatLong != null && destinationLatLong != null) {
      controller.confirmWidgetVisible.value = true;
      // conformationBottomSheet(context);
    }
  }

  Future<void> setDestinationMaker(LatLng destination) async {
    destinationLatLong = destination;
    if (points.length >= 2) {
      points[1] = destinationLatLong!;
    } else {
      points.add(destinationLatLong!);
    }

    _mapController?.clearLines();

    markers.remove('Destination');
    markers['Destination'] = MarkerLayer(
      ignorePointer: true,
      mapController: _mapController!,
      markers: [
        Marker(
          alignment: Alignment.bottomCenter,
          width: 30,
          height: 30,
          child: Icon(
            Icons.location_on,
            color: Colors.red,
            size: 30,
          ),
          latLng: LatLng(destination.latitude, destination.longitude),
        ),
      ],
    );
    _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(destination.latitude, destination.longitude),
        zoom: 14,
      )),
    );
    await bookController.fetchRouteData();
    bookController.addPolyline(_mapController);
    for (var point in points) {
      print('Lat: ${point.latitude}, Lng: ${point.longitude}');
    }

    if (pickupLatLong != null && destinationLatLong != null) {
      controller.confirmWidgetVisible.value = true;
      // conformationBottomSheet(context);
    }
  }

  confirmWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 20),
      child: Row(
        children: [
          Expanded(
            child: ButtonThem.buildButton(context, btnHeight: 40, title: "Continue".tr, btnColor: ConstantColors.primary, txtColor: Colors.white, onPress: () async {
             /* await controller.getDurationDistance(departureLatLong!, destinationLatLong!).then((durationValue) async {
                if (durationValue != null) {
                  await controller.getUserPendingPayment().then((value) async {
                    if (value != null) {
                      if (value['success'] == "success") {
                        if (value['data']['amount'] != 0) {
                          _pendingPaymentDialog(context);
                        } else {
                          if (Constant.distanceUnit == "KM") {
                            controller.distance.value = durationValue['rows'].first['elements'].first['distance']['value'] / 1000.00;
                          } else {
                            controller.distance.value = durationValue['rows'].first['elements'].first['distance']['value'] / 1609.34;
                          }

                          controller.duration.value = durationValue['rows'].first['elements'].first['duration']['text'];
                          // Get.back();
                          controller.confirmWidgetVisible.value = false;
                          tripOptionBottomSheet(context);
                        }
                      } else {
                        if (Constant.distanceUnit == "KM") {
                          controller.distance.value = durationValue['rows'].first['elements'].first['distance']['value'] / 1000.00;
                        } else {
                          controller.distance.value = durationValue['rows'].first['elements'].first['distance']['value'] / 1609.34;
                        }
                        controller.duration.value = durationValue['rows'].first['elements'].first['duration']['text'];
                        controller.confirmWidgetVisible.value = false;
                        // Get.back();
                        tripOptionBottomSheet(context);
                      }
                    }
                  });
                }
              });*/
            }),
          ),
        ],
      ),
    );
  }



}
