class LanguageData {
  String? language;
  String? languageCode;
  String? flag;
  String? subTitle;

  LanguageData({
    this.language,
    this.languageCode,
    this.flag,
    this.subTitle,
  });
}
