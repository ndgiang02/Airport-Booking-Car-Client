import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:location/location.dart';
import 'package:vietmap_flutter_gl/vietmap_flutter_gl.dart';
import 'package:vietmap_flutter_plugin/vietmap_flutter_plugin.dart';

import '../constant/constant.dart';

class TestController extends GetxController {

  var isLoading = true.obs;
  RxString selectedVehicle = "".obs;
  RxString tripOptionCategory = "General".obs;
  RxDouble distance = 0.0.obs;
  RxString duration = "".obs;
  var markers = <String, MarkerLayer>{}.obs;
  RxBool confirmWidgetVisible = false.obs;
  var suggestions = <dynamic>[].obs;
  Location location = Location();
  var polylinePoints = <LatLng>[].obs;
  List<LatLng> points = [];
  var isMapDrawn = false.obs;

  @override
  void onInit() {
    super.onInit();
  }

/*  void clearPickupMarker() {
    if (markers.containsKey('Pickup')) {
      markers.remove('Pickup');
      points.remove(pickupLatLong.value);
      pickupLatLong.value = null;
    }
  }

  void clearDestinationMarker() {
    if (markers.containsKey('Destination')) {
      markers.remove('Destination');
      points.remove(destinationLatLong.value);
      destinationLatLong.value = null;
    }
  }
  */

  clearData() {
    selectedVehicle.value = "";
    tripOptionCategory = "General".obs;
    distance = 0.0.obs;
    duration = "".obs;
  }


  Future<Map<String, dynamic>?> getCurrentLocation(LatLng pickup) async {
    try {
      LocationData position = await location.getLocation();
      pickup = LatLng(position.latitude!, position.longitude!);
      final result = await Vietmap.reverse(
          LatLng(position.latitude!, position.longitude!));
      return result.fold(
            (failure) {
          debugPrint('Error: $failure');
          return null;
        },
            (VietmapReverseModel) {
          return {
            'lat': VietmapReverseModel.lat.toString(),
            'lng': VietmapReverseModel.lng.toString(),
            'display': VietmapReverseModel.display ?? '',
          };
        },
      );
    } catch (e) {
      debugPrint('Error: $e');
      return null;
    }
  }

  Future<LatLng?> reverseGeocode(String refId) async {
    final url =
        '${Constant.baseUrl}/place/v3?apikey=${Constant.VietMapApiKey}&refid=$refId';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data != null && data['lat'] != null && data['lng'] != null) {
          double lat = data['lat'];
          double lng = data['lng'];
          return LatLng(lat, lng);
        }
      } else {
        debugPrint('Error: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('Error: $e');
    }
    return null;
  }

  Future<List<Map<String, String>>> getAutocompleteData(String value) async {
    final result = await Vietmap.autocomplete(
        VietMapAutoCompleteParams(textSearch: value));
    return result.fold(
          (failure) {
        debugPrint('Error: $failure');
        return [];
      },
          (autocompleteList) {
        var resultList = <Map<String, String>>[];
        for (var item in autocompleteList) {
          final refId = item.refId ?? '';
          final display = item.display ?? '';

          resultList.add({
            'ref_id': refId,
            'display': display,
          });
        }
        suggestions.value =
            resultList.where((item) => item['ref_id']!.isNotEmpty).toList();
        return resultList;
      },
    );
  }

  ///Route
  Future<void> fetchRouteData() async {
    final url = Uri.parse('${Constant.baseUrl}/route?api-version=1.1&apikey=${Constant.VietMapApiKey}&point=${points.map((p) => '${p.latitude},${p.longitude}').join('&point=')}&points_encoded=true&vehicle=car');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final encodedPolyline = data['paths'][0]['points'];
        polylinePoints.value = decodePolyline(encodedPolyline);
      } else {
        throw Exception('Failed to load route data');
      }
    } catch (e) {
      print('Error fetching route data: $e');
    } finally {
      isLoading.value = false;
    }
  }

  List<LatLng> decodePolyline(String encoded) {
    List<LatLng> points = [];
    int index = 0, len = encoded.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;
      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;
      points.add(LatLng(
        (lat / 1E5).toDouble(),
        (lng / 1E5).toDouble(),
      ));
    }
    return points;
  }

  Future<void> addPolyline(VietmapController? mapController) async {
    if (mapController != null && polylinePoints.isNotEmpty) {

      await mapController.addPolyline(
        PolylineOptions(
            geometry: polylinePoints,
            polylineColor: Colors.blue,
            polylineWidth: 5.0,
            draggable: true
        ),
      );

      await mapController.addSymbol(
        SymbolOptions(
          geometry: polylinePoints.first,
          iconImage: ic_pickup,
          iconSize: 1.5,
        ),
      );

      await mapController.addSymbol(
        SymbolOptions(
          geometry: polylinePoints.last,
          iconImage: ic_dropoff,
          iconSize: 1.5,
        ),
      );

      double? minLat, minLng, maxLat, maxLng;

      for (var point in polylinePoints) {
        if (minLat == null || point.latitude < minLat) {
          minLat = point.latitude;
        }
        if (minLng == null || point.longitude < minLng) {
          minLng = point.longitude;
        }
        if (maxLat == null || point.latitude > maxLat) {
          maxLat = point.latitude;
        }
        if (maxLng == null || point.longitude > maxLng) {
          maxLng = point.longitude;
        }
      }

      final bounds = LatLngBounds(
        southwest: LatLng(minLat!, minLng!),
        northeast: LatLng(maxLat!, maxLng!),
      );

      await mapController.setCameraBounds(
          west: minLat,
          north: maxLng,
          south: minLat,
          east: maxLng,
          padding: 50
      );

      await mapController.animateCamera(
        CameraUpdate.newLatLngBounds(bounds),
      );
    }
  }

}