import 'package:get/get.dart';

class ManageController extends GetxController {
  var userName = 'Nguyễn Duy Giang'.obs;
  var phoneNumber = '0847111862'.obs;
}
